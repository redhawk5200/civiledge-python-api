import os
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from contextlib import contextmanager

DB_FILE = "sqlite_database.db"

if not os.path.exists(DB_FILE):
    open(DB_FILE, 'a').close()

DATABASE_URL = f"sqlite:///{DB_FILE}"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

jobstores = {
    'default': SQLAlchemyJobStore(url=DATABASE_URL)
}

def get_db():
    """
    Create a new database session and close it after use.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
